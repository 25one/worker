-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 08, 2018 at 06:41 PM
-- Server version: 5.5.61-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yii2-basic`
--

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE IF NOT EXISTS `worker` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `sociability` int(2) NOT NULL,
  `engineering` int(2) NOT NULL,
  `timemanagement` int(2) NOT NULL,
  `languages` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sociability` (`sociability`,`engineering`,`timemanagement`,`languages`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`id`, `name`, `photo`, `sociability`, `engineering`, `timemanagement`, `languages`) VALUES
(67, 'alex', 'img/alex_image.jpg', 7, 9, 9, 7),
(68, 'serg', 'img/serg_image.jpg', 8, 7, 10, 7),
(69, 'maks', 'img/nophoto.jpg', 10, 6, 6, 9),
(76, 'maria', 'img/maria_image.jpg', 10, 7, 8, 9);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
