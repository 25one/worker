<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\Upload;
use yii\web\UploadedFile;

class UploadController extends Controller
{
    public function actionIndex()
    {
        $model_uploud = new Upload();

        if (Yii::$app->request->isPost) {
            $model_uploud->file = UploadedFile::getInstance($model_uploud, 'file');
            if ($model_uploud->file && !$model_uploud->specialValidation($model_uploud->file)) {              
                $model_uploud->file->saveAs('img/' . $model_uploud->file->baseName . '.' . $model_uploud->file->extension);
                $model_uploud->place = 'img/' . $model_uploud->file->baseName . '.' . $model_uploud->file->extension;
            }
            else if($model_uploud->file && $model_uploud->specialValidation($model_uploud->file)){
                $model_uploud->validation_error = $model_uploud->specialValidation($model_uploud->file);   
            }
        }
        return $this->renderPartial('upload', ['model_uploud' => $model_uploud]);
    }
}