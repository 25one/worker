<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

class Project extends ActiveRecord
{

    public function rules()
    {
       return [
          //...
       ];
    }

}
